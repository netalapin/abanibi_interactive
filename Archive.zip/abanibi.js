(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.ignorePause = false;
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.Image = function() {
	this.initialize(img.Image);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1781,919);


(lib.Image_1 = function() {
	this.initialize(img.Image_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,7773,4463);


(lib.FlashAICBAssets = function() {
	this.initialize(img.FlashAICBAssets);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,355,286);


(lib.FlashAICBAssets_1 = function() {
	this.initialize(img.FlashAICBAssets_1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,277);


(lib.FlashAICBAssets_2 = function() {
	this.initialize(img.FlashAICBAssets_2);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,278);


(lib.FlashAICBAssets_3 = function() {
	this.initialize(img.FlashAICBAssets_3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,279);


(lib.FlashAICBAssets_4 = function() {
	this.initialize(img.FlashAICBAssets_4);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,285);


(lib.FlashAICBAssets_5 = function() {
	this.initialize(img.FlashAICBAssets_5);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,285);


(lib.FlashAICBAssets_6 = function() {
	this.initialize(img.FlashAICBAssets_6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,268,285);


(lib.FlashAICBAssets_7 = function() {
	this.initialize(img.FlashAICBAssets_7);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,277);


(lib.FlashAICBAssets_8 = function() {
	this.initialize(img.FlashAICBAssets_8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,285);


(lib.FlashAICBAssets_9 = function() {
	this.initialize(img.FlashAICBAssets_9);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,265,277);


(lib.linkfaqulty = function() {
	this.initialize(img.linkfaqulty);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,264,38);


(lib.odot = function() {
	this.initialize(img.odot);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,8002,4501);


(lib.songagain = function() {
	this.initialize(img.songagain);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songbroke = function() {
	this.initialize(img.songbroke);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songfreha = function() {
	this.initialize(img.songfreha);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songharuv = function() {
	this.initialize(img.songharuv);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songkid = function() {
	this.initialize(img.songkid);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songknow = function() {
	this.initialize(img.songknow);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songlife = function() {
	this.initialize(img.songlife);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songprince = function() {
	this.initialize(img.songprince);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songwhere = function() {
	this.initialize(img.songwhere);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.songyou = function() {
	this.initialize(img.songyou);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,1917,1079);


(lib.x = function() {
	this.initialize(img.x);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,113,113);// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop, this.reversed));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib._1979 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("ABRBnQgDgNgCg0IgDg3QgCgOgFgIQgDgFgDAAQgEAAgdARQghAUglAAQgkAAgNgOQgMgOAAgVQABgVALgQQAMgQATgGQAFgBAPAAIALAAQBFACAfAgQAjAmAABfIAAANQgBAigCAJQgCAKgGAAQgKAAgDgOgAg6hTQgOAJAAASQAAAHAEAFQAFAHATAAQAVAAASgHQAJgEAPgKQAPgJAAgCQAAgDgNgGQgPgGgHgCQgMgDgNAAQgWAAgKAGg");
	this.shape.setTransform(31.2111,-4.4574,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgaAKgoQAJgmAMgXIALgUQADgIgFgEQgFgEgHAAIgsABQggABgJgJQgGgDAAgIQAAgGADgEIAFgFICMgCIAEAAQARAAAHAEQAJAEAAALQAAAEgUATQgfAdgNAcQgJAQgKAkQgJAngBAWIgBASIgIABg");
	this.shape_1.setTransform(21.6138,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgNgCg0IgDg3QgCgOgFgIQgDgFgDAAQgFAAgcARQghAUglAAQgkAAgNgOQgMgOAAgVQABgVALgQQALgQAUgGQAFgBAPAAIALAAQBFACAfAgQAjAmAABfIAAANQgBAigCAJQgCAKgGAAQgKAAgDgOgAg6hTQgOAKAAARQAAAHAEAFQAFAHATAAQAVAAASgHQAJgEAPgKQAPgJAAgCQAAgDgNgGQgPgGgHgCQgMgDgNAAQgWAAgKAGg");
	this.shape_2.setTransform(12.0927,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAALADQALAEAPAAQAKAAACgCQAEgDAAhVIgBgbIgIALQgXAggPAAQgFAAgDgDQgEgDAAgEQAAgGAGgGQAIgHAIgLQAIgNAEgLQAFgPAGgeQALgxAFgJQADgEAFAAQAIAAAFAFQADAEAAAUIAAAsIgBBnQAABCABACQABABAcAAIAJAAQAQAAAEACQAFABAAAHQAAAIgHADQgMACgYABIgUAAQhMAAgLgGg");
	this.shape_3.setTransform(2.9905,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1979, new cjs.Rectangle(0,-10.4,35.3,10.4), null);


(lib._1978 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgSB6QgfgCgSgSQgPgPgGgWQgDgLAAgKQAAgaAagbQAJgIAAgEQAAgDgFgMQgHgPAAgRQAAgLADgFQAMgZAkgKQAGgCAMAAQATAAAMAEQAJACAJAIQAIAIADAIQAEAMAAAOQAAARgDAIIgEAPQAAAFAKAKQAKAKAIAPQAGAMAAAJIAAAMQgBAPgEALQgEAJgKALQgLAMgXAIQgYAIgXAAgAgSgBQgZAHgLAWQgEAKAAAFIABAEIAAAEQADAnAvAAQAZAAATgKQATgKAFgSIABgHQAAgNgJgLQgJgMgOgFQgSgGgSAAQgHAAgFABgAgThZQgFADgEAFQgGAGAAAKQAAAKAFAHQAHAKAVAAQAFAAAJgCQAUgHAAgUQAAgPgNgFQgGgEgQAAQgLAAgGACg");
	this.shape.setTransform(30.6762,-4.6574,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgcAJgmQALgmALgXIALgUQADgIgFgEQgEgEgIAAIgsABQghABgIgJQgGgDAAgIQAAgGADgEIAEgFICNgCIAEAAQARAAAHAEQAJAFAAAKQAAAEgUATQgfAdgNAcQgKATgJAhQgJAhgBAcIgCASIgHABg");
	this.shape_1.setTransform(21.6312,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgRgCgwIgDg3QgDgPgEgHQgDgFgDAAQgFAAgcARQggAUgmAAQgkAAgNgOQgMgOAAgVQABgVALgQQALgQAUgGQAEgBAQAAIALAAQBFACAfAgQAjAlAABgIAAANQgBAhgCAKQgCAKgGAAQgKAAgDgOgAg6hTQgOAJAAASQAAAHAEAFQAFAHAUAAQAUAAASgHQALgFAOgJQAOgJAAgCQAAgDgOgGQgOgGgHgCQgMgDgNAAQgWAAgKAGg");
	this.shape_2.setTransform(12.1006,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAALADQALAEAPAAQAKAAADgCQADgDAAhVIgBgbIgIALQgXAggPAAQgFAAgEgDQgCgDAAgEQAAgGAFgGQAJgIAGgKQAJgMAEgMQAFgPAHgeQAJgvAHgLQACgEAGAAQAGAAAGAFQAEAEgBAUIAAAsIgBBnQAABCABACQABABAdAAIAIAAQAQAAAFACQADABAAAHQABAJgIACQgKACgZABIgUAAQhMAAgLgGg");
	this.shape_3.setTransform(2.9984,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1978, new cjs.Rectangle(0,-10.4,34.3,10.4), null);


(lib._1977 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgdAKglQAJgmAMgXIALgUQADgIgFgEQgEgEgIAAIgsABQghABgIgJQgGgDAAgIQAAgGADgEIAFgFICMgCIAEAAQARAAAHAEQAJAEAAALQAAAEgUATQgfAdgNAcQgJAQgKAkQgJAmgBAXIgBASIgIABg");
	this.shape.setTransform(30.7985,-4.4289,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgdAKglQAJgmAMgXIALgUQADgIgFgEQgEgEgIAAIgsABQghABgIgJQgGgDAAgIQAAgGADgEIAFgFICMgCIAEAAQARAAAHAEQAJAEAAALQAAAEgUATQgfAdgNAcQgJAQgKAkQgJAmgBAXIgBASIgIABg");
	this.shape_1.setTransform(21.6583,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgRgCgwIgDg3QgDgPgDgHQgEgFgDAAQgFAAgcARQghAUgkAAQglAAgNgOQgMgOAAgVQABgVALgQQALgQAUgGIAUgBIALAAQBFACAeAgQAkAlAABgIAAANQgBAhgCAKQgCAKgGAAQgKAAgDgOgAg6hTQgOAKAAARQAAAHAEAFQAFAHAUAAQAUAAASgHQALgFAOgJQANgJAAgCQAAgDgMgGQgPgGgIgCQgKgDgNAAQgXAAgKAGg");
	this.shape_2.setTransform(12.1276,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAAKADQAMAEAPAAQAKAAADgCQADgDAAhVIgBgbIgIALQgXAggOAAQgGAAgDgDQgEgDAAgEQAAgGAGgGQAIgHAIgLQAIgNAEgLQAFgPAGgeQAKgvAGgLQADgEAFAAQAIAAAFAFQADAEAAAUIAAAsIgBBnQAABCABACQABABAcAAIAJAAQAQAAAEACQAFABgBAHQAAAJgGACQgMACgYABIgUAAQhLAAgMgGg");
	this.shape_3.setTransform(3.0255,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1977, new cjs.Rectangle(0,-10.4,34.4,10.4), null);


(lib._1976 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AACB6QgggCgTgLQgkgVgDgoIgBgLQAAgjAQgmQAQglAdgeQARgSAGAAQADAAAFAEQAFAEAAAEQAAAHgPATQgoAvAAAcQAAAJAEAAIARgDQAUgGATAAQAXAAAUAIQARAHAIAMQAIAMABAUIAAAFQAAAegVASQgVASglAAgAgQAZQgYAHgIAPQgCAHAAADQAAAFABACQADARAOAGQAJAFAUAAQAjAAAQgLQALgIAAgTQAAgTgQgIQgKgFgXAAQgQAAgKADg");
	this.shape.setTransform(30.6018,-4.6669,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgaAKgoQAJgmAMgXIALgUQADgHgFgFQgEgEgIAAIgrABQghABgKgJQgFgEAAgHQAAgGADgEIAEgFIBGAAIBHgCIAEAAQARAAAHAEQAJAEAAALQAAAFgUASQggAegMAbQgJAQgKAkQgJAhgBAcIgBASIgIABg");
	this.shape_1.setTransform(21.6424,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgMgCg1QgBgggDgXQgBgPgFgHQgDgFgCAAQgGAAgcARQghAUglAAQglAAgMgOQgMgOAAgVQAAgVAMgQQAMgQASgGQAGgBAOAAIAMAAQBFACAfAgQAjAmAABfIAAANQgBAigCAJQgBAKgHAAQgKAAgDgOgAg6hTQgOAJAAASQAAAIAEAEQAFAHATAAQAVAAASgHQAKgFAOgJQAOgJABgCQgBgDgNgGQgNgGgIgCQgLgDgOAAQgWAAgKAGg");
	this.shape_2.setTransform(12.1213,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAALADQAMAEAPAAQAJAAADgCQADgCAAhWIAAgbIgJALQgXAggPAAQgFAAgDgDQgEgEAAgDQAAgFAHgHQAIgIAHgKQAHgLAFgNQAFgPAHgeQAJguAGgMQADgEAGAAQAHAAAFAFQADADAAAVIgBCTQAABCABACQABABAdAAIAIAAQARAAADACQAFABAAAHQAAAIgHADQgLACgZABIgUAAQhLAAgMgGg");
	this.shape_3.setTransform(3.0096,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1976, new cjs.Rectangle(0,-10.4,34.1,10.4), null);


(lib._1975 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhUBKQgHgLAAgFQAAgFAGgEQADgCADAAQAIAAAGAIQADAEALAJQANAIAJAEQALADALAAIANAAQA1gCAJgdQABgEAAgFQAAgZgYgQQgMgGgMgDQgOgDgbgCQgegBgIgDQgKgCgDgJQgBgEgDgWQgEgYgBgEQgBgFgJgEQgJgFAAgHQAAgJAQgDQAIgCA6AAQA4ABAEADQAKAEAAAIIgBADQgBAGgJACQgJACgfABQggABgIAEQgIAEAAAOQAAAJAFAFQAEAEADABIAOABQBIAAAfAlQARATAAAeQAAAUgEAKQgNAbgsAMQgVAFgRAAQg4AAgdgrg");
	this.shape.setTransform(31.0336,-4.4765,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgdAKglQAJgmAMgXIALgUQADgIgFgEQgEgEgIAAIgsABQghABgIgJQgGgDAAgIQAAgGADgEIAEgFICNgCIAEAAQARAAAHAEQAJAFAAAKQAAAEgUATQgfAdgNAcQgKATgJAhQgJAhgBAcIgBASIgIABg");
	this.shape_1.setTransform(21.6363,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgEgRgBgwIgDg3QgDgPgEgHQgDgFgCAAQgGAAgcARQggAUgmAAQgkAAgNgOQgMgOAAgVQABgVALgQQALgQATgGQAFgBAQAAIAMAAQBEACAfAgQAjAlAABgIAAANQgBAhgCAKQgCAKgGAAQgKAAgDgOgAg6hTQgOAKAAARQAAAHAEAFQAGAHASAAQAVAAASgHQALgFANgJQAPgJAAgCQAAgDgOgGQgOgGgHgCQgMgDgNAAQgWAAgKAGg");
	this.shape_2.setTransform(12.1056,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAALADQAMAEAPAAQAJAAACgCQAEgDAAhVIgBgbIgIALQgXAggPAAQgFAAgEgDQgCgDAAgEQgBgGAHgGQAIgIAGgKQAJgMAEgMQAFgPAHgeQAJgvAHgLQACgEAGAAQAGAAAGAFQADAEAAAUIAAAsIgBBnQAABCABACQABABAdAAIAIAAQARAAAEACQADABAAAHQAAAJgGACQgLACgZABIgUAAQhMAAgLgGg");
	this.shape_3.setTransform(3.0035,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1975, new cjs.Rectangle(0,-10.4,34.9,10.4), null);


(lib._1974 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AAXBKIgBgLIgVABIg+ADIgoACIgHgHQgHgFAAgGQAAgGAHgIQAjggAXgbQAWgbAhgyQAPgXAHgDQAGgDAFABQAJAAAFAFQAEAGAAARIgFCBIAZABQAbAAAFACQAIACAAAGQAAAEgFAEQgDADgPADQgNAEgJAAQgFAAgGADQgEACgBAFQgBAEAAATQgCAcgDAEQgFAFgDgBQgLAAgHg2gAgPgdIgjAsQgOATAAAEQAAABAAAAQAAABAAAAQABAAAAABQAAAAABAAIAHABIAugCQAcgDACgCQADgCACg2IAAggQAAgWgBAAQgGgBgiAvg");
	this.shape.setTransform(31.6273,-4.9049,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRIgBgQQAAgcAJgmQAKgkANgZIAKgUQADgIgFgEQgEgEgIAAIgsABQggABgJgJQgGgEAAgHQAAgGAEgEIADgFIBHAAIBGgCIAEAAQASAAAGAEQAJAEAAALQAAAFgUASQgeAdgOAcQgJAQgJAkQgKAhgBAcIgCASIgHABg");
	this.shape_1.setTransform(21.6397,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgNgCg0QgBgqgCgNQgCgPgFgHQgDgFgDAAQgFAAgcARQggAUglAAQglAAgNgOQgMgOAAgVQAAgVAMgQQALgQAUgGQAEgBAQAAIALAAQBFACAeAgQAkAmAABfIAAANQAAAigDAJQgCAKgGAAQgKAAgDgOgAg6hTQgOAJAAASQAAAHAEAFQAFAHAUAAQATAAATgHQAKgFAPgJQANgJAAgCQAAgDgNgGQgNgGgJgCQgKgDgOAAQgWAAgKAGg");
	this.shape_2.setTransform(12.1186,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAAKADQAMAEAPAAQAKAAADgCQADgDAAhVIgBgbIgJALQgWAggPAAQgFAAgEgDQgDgEAAgDQAAgFAGgHQAIgIAHgKQAKgOADgKQAFgPAHgeQAJguAGgMQADgEAFAAQAHAAAGAFQADAEAAAUIgBCTQAABCABACQACABAbAAIAJAAQARAAADACQAEABAAAHQABAIgIADQgKACgZABIgVAAQhLAAgLgGg");
	this.shape_3.setTransform(3.0164,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1974, new cjs.Rectangle(0,-10.4,36.1,10.4), null);


(lib._1973 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgMCMQgqAAgTgcQgGgIAAgHQAAgFADgDQACgCAFAAQAIAAAGAFQASAUAbAAQAOAAAPgHQARgIAHgKQAGgMABgTQgBgQgFgJQgMgYgYAAQgLAAgSAHQgTAGgHABIgHAAQgFAAgEgEQgFgFAAgIQAAgFAEgEQACgDASgGQAagIAJgNQALgOAAggQAAgRgEgFQgEgEgGAAIgGAAQgKACgIAHQgGAJgDAIQgEAQgIAAIgEgBQgNgDAAgPQAAgNALgRQALgQAUgFQAJgDAMAAQAJAAADACQAeALAAAyQgBAUgFARIgDAOIAHAFQAkATAMAiQACAKAAAOQAAATgFAOQgJAVgYAOQgZAOgbAAg");
	this.shape.setTransform(30.2401,-5.3289,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgdAKglQAJgmAMgXIALgUQADgIgFgEQgEgEgIAAIgsABQghABgIgJQgGgDAAgIQAAgGADgEIAFgFICMgCIAEAAQARAAAHAEQAJAEAAALQAAAEgUATQgfAdgNAcQgJAQgKAkQgJAmgBAXIgBASIgIABg");
	this.shape_1.setTransform(21.6616,-5.3289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgRgCgwIgDg3QgDgPgEgHQgDgFgCAAQgGAAgcARQggAUgmAAQgkAAgNgOQgMgOAAgVQABgVALgQQALgQAUgGIAUgBIALAAQBFACAfAgQAjAlAABgIAAANQgBAhgCAKQgCAKgGAAQgKAAgDgOgAg6hTQgOAKAAARQAAAHAEAFQAFAHAUAAQAUAAASgHQALgFANgJQAPgJAAgCQAAgDgNgGQgPgGgHgCQgMgDgNAAQgWAAgKAGg");
	this.shape_2.setTransform(12.131,-5.3574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAALADQALAEAQAAQAJAAADgCQADgDAAhVIgBgbIgIALQgXAggPAAQgFAAgDgDQgEgDABgEQAAgGAFgGQAIgHAIgLQAIgNAEgLQAFgPAHgeQAJgvAHgLQACgEAGAAQAHAAAFAFQAEAEgBAUIAAAsIgBBnQAABCABACQABABAdAAIAIAAQAQAAAFACQADABAAAHQAAAJgGACQgMACgYABIgUAAQhMAAgLgGg");
	this.shape_3.setTransform(3.0288,-6.1572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1973, new cjs.Rectangle(0,-11.3,33.3,11.3), null);


(lib._1972 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhdB7QgagBABgQQAAgKAJgKQAHgIAIgDQAKgEASgFQA3gPAQglQAJgTAAgZQAAgVgHgSQgHgRgKgEQgHgDgIAAQgQAAgPALQgPALgHARQgEALgBACQgDACgFAAQgRAAAAgOQAAgJAIgOQATggAegLQAKgDANAAIAJAAQATABAIAFQATAMAKAhQAGARAAAZIgBAYIgGASQgBAEgLATQgLASAAAFQAAACAxAAIArABQAIAAACADQAEAEAAAEQAAAFgEADQgDAFg2ABQg1ACgPADQgZAHgOALQgRANgWAAg");
	this.shape.setTransform(31.7934,-4.7003,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgLAAgFgRQgBgHAAgJQAAgcAJgmQALgmAMgXIAKgUQADgIgFgEQgEgEgIAAIgrABQgiABgIgJQgGgDAAgIQAAgGAEgEIADgFICOgCIADAAQASAAAGAEQAJAEAAALQAAAFgUASQgfAdgNAcQgKATgIAhQgKAhgBAcIgCASIgHABg");
	this.shape_1.setTransform(21.6629,-4.7289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgRgCgwIgDg3QgDgPgEgHQgDgFgCAAQgGAAgcARQggAUgmAAQgkAAgNgOQgMgOAAgVQAAgVAMgQQALgQAUgGQAEgBAQAAIALAAQBGACAeAgQAjAlAABgIAAANQgBAhgCAKQgCAKgGAAQgKAAgDgOgAg6hTQgOAJAAASQAAAHAEAFQAFAHAUAAQAUAAASgHQALgFANgJQAPgJAAgCQAAgDgOgGQgOgGgHgCQgMgDgNAAQgWAAgKAGg");
	this.shape_2.setTransform(12.1418,-4.7574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAALADQALAEAQAAQAJAAADgCQADgDAAhVIgBgbIgIALQgXAggPAAQgFAAgEgDQgCgDAAgEQAAgGAFgGQAJgIAGgKQAJgMAEgMQAFgPAHgeQAJgvAHgLQACgEAGAAQAGAAAGAFQADAEAAAUIAAAsIgBBnQAABCABACQACABAcAAIAIAAQAQAAAFACQADABAAAHQAAAJgHACQgKACgZABIgUAAQhMAAgLgGg");
	this.shape_3.setTransform(3.0396,-5.5572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1972, new cjs.Rectangle(0,-10.7,36.4,10.7), null);


(lib._1971 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAALADQALAEAQAAQAJAAADgCQADgCAAhWIgBgbIgIALQgXAggPAAQgFAAgDgDQgEgDAAgEQAAgGAHgGQAIgIAHgKQAIgNAEgLQAEgKAHgjQALgxAFgJQADgEAFAAQAIAAAFAFQADADAAAVIgBCTQAABCABACQABABAdAAIAIAAQAQAAAEACQAFABAAAHQAAAIgHADQgLACgZABIgUAAQhLAAgMgGg");
	this.shape.setTransform(30.3061,-5.2572,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgdAKglQAJgmAMgXIALgUQADgIgFgEQgEgEgIAAIgsABQghABgIgJQgGgDAAgIQAAgGADgEIAEgFICNgCIAEAAQARAAAHAEQAJAEAAALQAAAEgUATQgfAdgNAcQgKATgJAhQgJAmgBAXIgBASIgIABg");
	this.shape_1.setTransform(21.68,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgRgCgwIgDg3QgDgPgEgHQgDgFgDAAQgFAAgcARQggAUglAAQglAAgNgOQgMgOAAgVQABgVALgQQALgQAUgGIAUgBIALAAQBFACAeAgQAkAlAABgIAAANQgBAhgCAKQgCAKgGAAQgKAAgDgOgAg6hTQgOAKAAARQAAAHAEAFQAFAHAUAAQAUAAASgHQALgFAOgJQANgJAAgCQAAgDgMgGQgOgGgJgCQgKgDgOAAQgWAAgKAGg");
	this.shape_2.setTransform(12.1494,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAAKADQAMAEAPAAQAKAAADgCQADgDAAhVIgBgbIgIALQgXAggOAAQgGAAgEgDQgCgDAAgEQAAgGAFgGQAIgIAIgKQAIgMAEgMQAFgPAHgeQAJgvAGgLQADgEAFAAQAHAAAGAFQAEAEgBAUIAAAsIgBBnQAABCABACQABABAcAAIAJAAQAQAAAFACQADABAAAHQABAJgIACQgKACgZABIgUAAQhLAAgMgGg");
	this.shape_3.setTransform(3.0472,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1971, new cjs.Rectangle(0,-10.4,33.4,10.4), null);


(lib._1970 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgtBmQgSgRgHgcQgDgLAAgjQAAgoAEgSQAGgvAPgPQAJgJAGgBIAMAAQAaAAAOAEQAnAPANA4QADALAAAhIgBAVQgGAsgUAcQgUAbgbAAQgZAAgUgSgAgehcQgEADgCAGQgEAIgCAPQgIAsAAAfQAAAtAWAXQAMALANABQAGAAAEgCQARgGAMgbQANgZABgjIAAgMQAAgYgMgaQgNgWgRgIQgIgDgNABQgLAAgGACg");
	this.shape.setTransform(30.0189,-4.6574,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgMB0QgMAAgEgRQgBgHAAgJQAAgcAJgmQALgmALgXIALgUQADgIgFgEQgEgEgIAAIgrABQghABgJgJQgGgDAAgIQAAgGAEgEIAEgFICMgCIAEAAQARAAAHAEQAJAEAAALQAAAFgUASQgfAdgNAcQgKATgJAhQgJAhgBAcIgCASIgHABg");
	this.shape_1.setTransform(21.6689,-4.4289,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("ABRBnQgDgRgCgwIgDg3QgDgPgDgHQgEgFgDAAQgFAAgcARQggAUglAAQglAAgNgOQgMgOAAgVQAAgVAMgQQALgQAUgGQAEgBAQAAIALAAQBFACAeAgQAkAlAABgIAAANQAAAhgDAKQgCAKgGAAQgKAAgDgOgAg6hTQgOAJAAASQAAAHAEAFQAFAHAUAAQAUAAATgHQAKgFAOgJQANgJAAgCQAAgDgMgGQgOgGgJgCQgKgDgOAAQgWAAgKAGg");
	this.shape_2.setTransform(12.1573,-4.4574,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AhFCBQgLgGAAgIQAAgLAMAAQAHAAAKADQAMAEAPAAQAKAAADgCQADgDAAhVIAAgbIgJALQgXAggOAAQgGAAgDgDQgDgDAAgEQAAgGAFgGQAIgIAIgKQAIgMAEgMQAFgPAHgeQAJgvAGgLQADgEAFAAQAHAAAGAFQADAEAAAUIAAAsIgBBnQAABCABACQACABAbAAIAJAAQAQAAAFACQADABABAHQAAAJgIACQgKACgZABIgUAAQhLAAgMgGg");
	this.shape_3.setTransform(3.0551,-5.2572,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib._1970, new cjs.Rectangle(0,-10.4,32.9,10.4), null);


(lib.pop_you = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songyou();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_you, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_where = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songwhere();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_where, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_prince = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songprince();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_prince, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_life = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songlife();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_life, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_know = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songknow();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_know, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_kid = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songkid();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_kid, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_haruv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songharuv();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_haruv, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_freha = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songfreha();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_freha, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_broke = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songbroke();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_broke, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.pop_again = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.songagain();
	this.instance.setTransform(0,-470.8,0.4363,0.4363);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.pop_again, new cjs.Rectangle(0,-470.8,836.5,470.8), null);


(lib.buttonX = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.x();
	this.instance.setTransform(0,-26.1,0.231,0.231);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-26.1,26.1,26.1);


(lib.odot_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#F2F4F5").s().p("AA1BlIhKhyIgkByIgkAAIAyiVIgig0IAnAAIA8BeIAbheIAlAAIgqB+IAyBLg");
	this.shape.setTransform(37.7767,-10.7126,0.3808,0.3808);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#F2F4F5").s().p("AgQBlIAAifIgFgqIAlAAIAGAqIAACfg");
	this.shape_1.setTransform(32.1213,-10.7126,0.3808,0.3808);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#F2F4F5").s().p("AAHBlIAAiCQAAgcAKgNIhgAAIAAgeICfAAIAAAeIgbAAQgIAOAAAbIAACCg");
	this.shape_2.setTransform(26.7993,-10.7126,0.3808,0.3808);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#F2F4F5").s().p("AgQBlIAAifIgFgqIAmAAIAEAqIAACfg");
	this.shape_3.setTransform(21.4391,-10.7126,0.3808,0.3808);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#F2F4F5").s().p("AhgBNQAVgCAHgKQAIgIAAgVIAAiLIBgAAQAdAAAQAQQAQAQAAAjIAACGIgnAAIAAiHQAAgUgIgIQgIgJgQABIgwAAIAABpQAAAkgRAQQgQARglADg");
	this.shape_4.setTransform(15.3173,-10.5983,0.3808,0.3808);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#39698A").s().p("ArKEJIAAoRIWUAAIAAIRg");
	this.shape_5.setTransform(27.2302,-11.8348,0.3808,0.3808);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#347395").s().p("ArJEJIAAoRIWTAAIAAIRg");
	this.shape_6.setTransform(29.1249,-10.0829,0.3808,0.3808);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-21.9,56.4,21.9);


(lib.link = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.linkfaqulty();
	this.instance.setTransform(0,-14.55,0.3826,0.3826);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-14.5,101,14.5);


(lib.Rectangle_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.1,99.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_8, new cjs.Rectangle(9.7,7.6,184.8,184.8), null);


(lib.Rectangle_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.2,99.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_7, new cjs.Rectangle(9.8,7.6,184.79999999999998,184.8), null);


(lib.Rectangle_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.3,99.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_6, new cjs.Rectangle(9.9,7.6,184.79999999999998,184.8), null);


(lib.Rectangle_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.35,99.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_5, new cjs.Rectangle(10,7.6,184.8,184.8), null);


(lib.Rectangle_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(101.45,99.95);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_4, new cjs.Rectangle(9.1,7.6,184.8,184.8), null);


(lib.Rectangle_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.1,99.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_3, new cjs.Rectangle(9.7,7.5,184.8,184.8), null);


(lib.Rectangle_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.2,99.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_2, new cjs.Rectangle(9.8,7.5,184.79999999999998,184.8), null);


(lib.Rectangle_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.3,99.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_1, new cjs.Rectangle(9.9,7.5,184.79999999999998,184.8), null);


(lib.Rectangle_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(102.35,99.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle_0, new cjs.Rectangle(10,7.5,184.8,184.8), null);


(lib.Rectangle = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AubOcIAA83Ic3AAIAAc3g");
	this.shape.setTransform(101.45,99.9);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Rectangle, new cjs.Rectangle(9.1,7.5,184.8,184.8), null);


(lib.Path_8 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuZDbIjTm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_8, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_7 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuYDbIjTm1MAjXAAAIjNG1g");
	this.shape.setTransform(113.225,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_7, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_6 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuYDbIjUm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_6, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_5 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuZDbIjTm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_5, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_4 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuZDbIjTm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_4, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_3 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuZDbIjTm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_3, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_2 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuYDbIjTm1MAjXAAAIjNG1g");
	this.shape.setTransform(113.225,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_2, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_1 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuYDbIjUm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_1, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path_0 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuZDbIjTm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path_0, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.Path = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#3A3A3A").s().p("AuZDbIjTm1MAjZAAAIjOG1g");
	this.shape.setTransform(113.25,21.85);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.Path, new cjs.Rectangle(0,0,226.5,43.7), null);


(lib.youandme = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_4();
	this.instance.setTransform(113.55,-92.35,1,1,0,0,0,101.5,100);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_4();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_5();
	this.instance_2.setTransform(-19,-270);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-19,-270,265,285.2);


(lib.toknow = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_7();
	this.instance.setTransform(113.5,-92.35,1,1,0,0,0,102.2,100);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_7();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_2();
	this.instance_2.setTransform(-10,-264);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-10,-264,265,279.2);


(lib.somewhere = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_5();
	this.instance.setTransform(113.55,-92.35,1,1,0,0,0,102.4,100);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_5();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_4();
	this.instance_2.setTransform(-22,-274);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-22,-274,265,289.2);


(lib.prince = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_6();
	this.instance.setTransform(113.55,-92.35,1,1,0,0,0,102.3,100);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_6();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_3();
	this.instance_2.setTransform(-18,-275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-18,-275,265,290.2);


(lib.mylife = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_1();
	this.instance.setTransform(113.55,-92.4,1,1,0,0,0,102.3,99.9);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_1();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_8();
	this.instance_2.setTransform(-17,-283);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17,-283,265,298.2);


(lib.kindergarden = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_3();
	this.instance.setTransform(113.5,-92.4,1,1,0,0,0,102.1,99.9);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_3();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_6();
	this.instance_2.setTransform(-14,-275);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-14,-275,268,290.2);


(lib.haruv = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle();
	this.instance.setTransform(113.55,-92.4,1,1,0,0,0,101.5,99.9);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets();
	this.instance_2.setTransform(-65,-277);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-65,-277,355,292.2);


(lib.freha = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_8();
	this.instance.setTransform(113.5,-92.35,1,1,0,0,0,102.1,100);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_8();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_1();
	this.instance_2.setTransform(-11,-266);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-11,-266,265,281.2);


(lib.brokeup = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_0();
	this.instance.setTransform(113.55,-92.4,1,1,0,0,0,102.4,99.9);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_0();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_9();
	this.instance_2.setTransform(-17,-268);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-17,-268,265,283.2);


(lib.again = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.instance = new lib.Rectangle_2();
	this.instance.setTransform(113.5,-92.4,1,1,0,0,0,102.2,99.9);
	this.instance.shadow = new cjs.Shadow("rgba(0,0,0,0.769)",0,2,9);

	this.instance_1 = new lib.Path_2();
	this.instance_1.setTransform(113.2,-21.8,1,1,0,0,0,113.2,21.9);
	this.instance_1.alpha = 0.1484;

	this.instance_2 = new lib.FlashAICBAssets_7();
	this.instance_2.setTransform(-8,-268);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.instance}]}).to({state:[{t:this.instance_2}]},1).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-8,-268,265,283.2);


(lib.odot_p = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.link = new lib.link();
	this.link.name = "link";
	this.link.setTransform(363.5,-140.75,1,1,0,0,0,50.5,-7.3);
	new cjs.ButtonHelper(this.link, 0, 1, 1);

	this.instance = new lib.odot();
	this.instance.setTransform(0,-442.85,0.0984,0.0984);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance},{t:this.link}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.odot_p, new cjs.Rectangle(0,-442.8,787.3,442.8), null);


// stage content:
(lib.abanibi = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [0];
	this.isSingleFrame = false;
	// timeline functions:
	this.frame_0 = function() {
		if(this.isSingleFrame) {
			return;
		}
		if(this.totalFrames == 1) {
			this.isSingleFrame = true;
		}
		var self = this;
		stage.enableMouseOver(24);
		
		
		//hide pop-ups
		self.odot_p.visible = false;
		self.X_odot.visible = false;
		
		self.pop_haruv.visible = false;
		self.pop_you.visible = false;
		self.pop_broke.visible = false;
		self.pop_where.visible = false;
		self.pop_life.visible = false;
		self.pop_prince.visible = false;
		self.pop_again.visible = false;
		self.pop_know.visible = false;
		self.pop_kid.visible = false;
		self.pop_freha.visible = false;
		
		self.X_pop.visible = false;
		
		//click on X button for all pop-ups
		
		self.X_pop.addEventListener ("click", click_X_pop);
		function click_X_pop() {
			
		self.pop_haruv.visible = false;
		self.pop_you.visible = false;
		self.pop_broke.visible = false;
		self.pop_where.visible = false;
		self.pop_life.visible = false;
		self.pop_prince.visible = false;
		self.pop_again.visible = false;
		self.pop_know.visible = false;
		self.pop_kid.visible = false;
		self.pop_freha.visible = false;
		
		self.X_pop.visible = false;	
			
		//allow clicking on rest of the songs
		self.odot_b.mouseEnabled = true;
		self.haruv.mouseEnabled = true;
		self.you.mouseEnabled = true;
		self.broke.mouseEnabled = true;
		self.where.mouseEnabled = true;
		self.life.mouseEnabled = true;
		self.prince.mouseEnabled = true;
		self.again.mouseEnabled = true;
		self.know.mouseEnabled = true;
		self.kid.mouseEnabled = true;
		self.freha.mouseEnabled = true;
			}
		
		
		//odot
		//open odot pop-up
		self.odot_b.addEventListener ("click", click_odot);
		
		function click_odot() {
			
		self.odot_p.visible = true;
		self.X_odot.visible = true;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;	
			}
		
		self.odot_b.cursor = "pointer"
		
		//exit odot pop-up
		self.X_odot.addEventListener ("click", click_X_odot);
		
		function click_X_odot() {
			
		self.odot_p.visible = false;
		self.X_odot.visible = false;
		
		//allow clicking on rest of the songs
		self.odot_b.mouseEnabled = true;
		self.haruv.mouseEnabled = true;
		self.you.mouseEnabled = true;
		self.broke.mouseEnabled = true;
		self.where.mouseEnabled = true;
		self.life.mouseEnabled = true;
		self.prince.mouseEnabled = true;
		self.again.mouseEnabled = true;
		self.know.mouseEnabled = true;
		self.kid.mouseEnabled = true;
		self.freha.mouseEnabled = true;	
			}
		
		//click on telem link
		self.odot_p.link.addEventListener("click", click_link);
		
		function click_link(){
			window.open('https://www.hit.ac.il/telem/overview');
		}
		
		//mouse over on years
		//1970
		self.zero.addEventListener ("mouseover", over_zero);
		self.zero.addEventListener ("mouseout", out_zero);
		
		function over_zero() {
			//show the song
			self.haruv.gotoAndStop(1);
		
			self.zero.scale = 1.5;
			
			self.zero.alpha = 1;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_zero() {
		//hide the song
			self.haruv.gotoAndStop(2);	
			
			self.zero.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1971
		self.one.addEventListener ("mouseover", over_one);
		self.one.addEventListener ("mouseout", out_one);
		
		function over_one() {
		//show the song
			self.you.gotoAndStop(1);
			
			self.one.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 1;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_one() {
		//hide the song
			self.you.gotoAndStop(2);	
				
			self.one.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1972
		self.two.addEventListener ("mouseover", over_two);
		self.two.addEventListener ("mouseout", out_two);
		
		function over_two() {
		//show the song
			self.broke.gotoAndStop(1);
			
			self.two.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 1;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_two() {
		//hide the song
			self.broke.gotoAndStop(2);	
				
			self.two.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1973
		self.three.addEventListener ("mouseover", over_three);
		self.three.addEventListener ("mouseout", out_three);
		
		function over_three() {
		//show the song
			self.where.gotoAndStop(1);
			
			self.three.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 1;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_three() {
		//hide the song
			self.where.gotoAndStop(2);	
				
			self.three.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1974
		self.four.addEventListener ("mouseover", over_four);
		self.four.addEventListener ("mouseout", out_four);
		
		function over_four() {
		//show the song
			self.life.gotoAndStop(1);
			
			self.four.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 1;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_four() {
		//hide the song
			self.life.gotoAndStop(2);	
				
			self.four.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1975
		self.five.addEventListener ("mouseover", over_five);
		self.five.addEventListener ("mouseout", out_five);
		
		function over_five() {
		//show the song
			self.prince.gotoAndStop(1);
			
			self.five.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 1;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_five() {
		//hide the song
			self.prince.gotoAndStop(2);	
				
			self.five.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1976
		self.six.addEventListener ("mouseover", over_six);
		self.six.addEventListener ("mouseout", out_six);
		
		function over_six() {
		//show the song
			self.again.gotoAndStop(1);
			
			self.six.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 1;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_six() {
		//hide the song
			self.again.gotoAndStop(2);	
				
			self.six.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1977
		self.seven.addEventListener ("mouseover", over_seven);
		self.seven.addEventListener ("mouseout", out_seven);
		
		function over_seven() {
		//show the song
			self.know.gotoAndStop(1);
			
			self.seven.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 1;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_seven() {
		//hide the song
			self.know.gotoAndStop(2);	
				
			self.seven.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1978
		self.eigth.addEventListener ("mouseover", over_eigth);
		self.eigth.addEventListener ("mouseout", out_eigth);
		
		function over_eigth() {
		//show the song
			self.kid.gotoAndStop(1);
			
			self.eigth.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 1;
			self.nine.alpha = 0.5;
		}
		
		function out_eigth() {
		//hide the song
			self.kid.gotoAndStop(2);	
				
			self.eigth.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//1979
		self.nine.addEventListener ("mouseover", over_nine);
		self.nine.addEventListener ("mouseout", out_nine);
		
		function over_nine() {
		//show the song
			self.freha.gotoAndStop(1);
			
			self.nine.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 1;
		}
		
		function out_nine() {
		//hide the song
			self.freha.gotoAndStop(2);	
				
			self.nine.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		
		//songs
		//show the year
		//1970 haruv
		self.haruv.addEventListener ("mouseover", over_haruv);
		self.haruv.addEventListener ("mouseout", out_haruv);
		
		function over_haruv() {
			self.zero.scale = 1.5;
			
			self.zero.alpha = 1;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_haruv() {
			self.zero.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.haruv.addEventListener ("click", click_haruv);
		
		function click_haruv() {
			
		self.pop_haruv.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;	
			}
		
		
		//1971 you and me
		self.you.addEventListener ("mouseover", over_you);
		self.you.addEventListener ("mouseout", out_you);
		
		function over_you() {
			self.one.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 1;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_you() {
			self.one.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.you.addEventListener ("click", click_you);
		
		function click_you() {
			
		self.pop_you.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
		
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1972 broke up like this
		self.broke.addEventListener ("mouseover", over_broke);
		self.broke.addEventListener ("mouseout", out_broke);
		
		function over_broke() {
			self.two.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 1;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_broke() {
			self.two.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.broke.addEventListener ("click", click_broke);
		
		function click_broke() {
			
		self.pop_broke.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1973 somewhere 
		self.where.addEventListener ("mouseover", over_where);
		self.where.addEventListener ("mouseout", out_where);
		
		function over_where() {
			self.three.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 1;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_where() {
			self.three.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.where.addEventListener ("click", click_where);
		
		function click_where() {
			
		self.pop_where.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1974 gave her my life
		self.life.addEventListener ("mouseover", over_life);
		self.life.addEventListener ("mouseout", out_life);
		
		function over_life() {
			self.four.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 1;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_life() {
			self.four.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.life.addEventListener ("click", click_life);
		
		function click_life() {
			
		self.pop_life.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1975 the little prince
		self.prince.addEventListener ("mouseover", over_prince);
		self.prince.addEventListener ("mouseout", out_prince);
		
		function over_prince() {
			self.five.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 1;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_prince() {
			self.five.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.prince.addEventListener ("click", click_prince);
		
		function click_prince() {
			
		self.pop_prince.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1976 again
		self.again.addEventListener ("mouseover", over_again);
		self.again.addEventListener ("mouseout", out_again);
		
		function over_again() {
			self.six.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 1;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_again() {
			self.six.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.again.addEventListener ("click", click_again);
		
		function click_again() {
			
		self.pop_again.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1977 wanted you to know
		self.know.addEventListener ("mouseover", over_know);
		self.know.addEventListener ("mouseout", out_know);
		
		function over_know() {
			self.seven.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 1;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 0.5;
		}
		
		function out_know() {
			self.seven.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.know.addEventListener ("click", click_know);
		
		function click_know() {
			
		self.pop_know.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.kid.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1978 most beautifull girl in kindergarden
		self.kid.addEventListener ("mouseover", over_kid);
		self.kid.addEventListener ("mouseout", out_kid);
		
		function over_kid() {
			self.eigth.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 1;
			self.nine.alpha = 0.5;
		}
		
		function out_kid() {
			self.eigth.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.kid.addEventListener ("click", click_kid);
		
		function click_kid() {
			
		self.pop_kid.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.freha.mouseEnabled = false;
			}
		
		//1979 song of the freha
		self.freha.addEventListener ("mouseover", over_freha);
		self.freha.addEventListener ("mouseout", out_freha);
		
		function over_freha() {
			self.nine.scale = 1.5;
			
			self.zero.alpha = 0.5;
			self.one.alpha = 0.5;
			self.two.alpha = 0.5;
			self.three.alpha = 0.5;
			self.four.alpha = 0.5;
			self.five.alpha = 0.5;
			self.six.alpha = 0.5;
			self.seven.alpha = 0.5;
			self.eigth.alpha = 0.5;
			self.nine.alpha = 1;
		}
		
		function out_freha() {
			self.nine.scale = 1;
			
			self.zero.alpha = 1;
			self.one.alpha = 1;
			self.two.alpha = 1;
			self.three.alpha = 1;
			self.four.alpha = 1;
			self.five.alpha = 1;
			self.six.alpha = 1;
			self.seven.alpha = 1;
			self.eigth.alpha = 1;
			self.nine.alpha = 1;
		}
		
		//open pop-up with click
		self.freha.addEventListener ("click", click_freha);
		
		function click_freha() {
			
		self.pop_freha.visible = true;
		self.X_pop.visible = true;
		self.odot_b.mouseEnabled = false;
			
		//can't click on rest of the songs
		self.haruv.mouseEnabled = false;
		self.you.mouseEnabled = false;
		self.broke.mouseEnabled = false;
		self.where.mouseEnabled = false;
		self.life.mouseEnabled = false;
		self.prince.mouseEnabled = false;
		self.again.mouseEnabled = false;
		self.know.mouseEnabled = false;
		self.kid.mouseEnabled = false;
			}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// song_pop_up
	this.X_pop = new lib.buttonX();
	this.X_pop.name = "X_pop";
	this.X_pop.setTransform(192.65,105.4);
	new cjs.ButtonHelper(this.X_pop, 0, 1, 1);

	this.pop_you = new lib.pop_you();
	this.pop_you.name = "pop_you";
	this.pop_you.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_where = new lib.pop_where();
	this.pop_where.name = "pop_where";
	this.pop_where.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_prince = new lib.pop_prince();
	this.pop_prince.name = "pop_prince";
	this.pop_prince.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_life = new lib.pop_life();
	this.pop_life.name = "pop_life";
	this.pop_life.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_know = new lib.pop_know();
	this.pop_know.name = "pop_know";
	this.pop_know.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_kid = new lib.pop_kid();
	this.pop_kid.name = "pop_kid";
	this.pop_kid.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_haruv = new lib.pop_haruv();
	this.pop_haruv.name = "pop_haruv";
	this.pop_haruv.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_freha = new lib.pop_freha();
	this.pop_freha.name = "pop_freha";
	this.pop_freha.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_broke = new lib.pop_broke();
	this.pop_broke.name = "pop_broke";
	this.pop_broke.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.pop_again = new lib.pop_again();
	this.pop_again.name = "pop_again";
	this.pop_again.setTransform(355.2,199.4,1,1,0,0,0,418.2,-235.4);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.pop_again},{t:this.pop_broke},{t:this.pop_freha},{t:this.pop_haruv},{t:this.pop_kid},{t:this.pop_know},{t:this.pop_life},{t:this.pop_prince},{t:this.pop_where},{t:this.pop_you},{t:this.X_pop}]}).wait(1));

	// odot_pop_up
	this.X_odot = new lib.buttonX();
	this.X_odot.name = "X_odot";
	this.X_odot.setTransform(184.3,84.6,1,1,0,0,0,13.1,-13.1);
	new cjs.ButtonHelper(this.X_odot, 0, 1, 1);

	this.odot_p = new lib.odot_p();
	this.odot_p.name = "odot_p";
	this.odot_p.setTransform(355.7,200.35,1,1,0,0,0,393.7,-221.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.odot_p},{t:this.X_odot}]}).wait(1));

	// song
	this.freha = new lib.freha();
	this.freha.name = "freha";
	this.freha.setTransform(559.15,337.65,0.3809,0.3809,0,0,0,113.3,-92.3);
	new cjs.ButtonHelper(this.freha, 0, 1, 1);

	this.know = new lib.toknow();
	this.know.name = "know";
	this.know.setTransform(452.95,337.65,0.3809,0.3809,0,0,0,113.3,-92.3);
	new cjs.ButtonHelper(this.know, 0, 1, 1);

	this.prince = new lib.prince();
	this.prince.name = "prince";
	this.prince.setTransform(346.7,337.65,0.3809,0.3809,0,0,0,113.3,-92.3);
	new cjs.ButtonHelper(this.prince, 0, 1, 1);

	this.where = new lib.somewhere();
	this.where.name = "where";
	this.where.setTransform(240.45,337.65,0.3809,0.3809,0,0,0,113.3,-92.3);
	new cjs.ButtonHelper(this.where, 0, 1, 1);

	this.you = new lib.youandme();
	this.you.name = "you";
	this.you.setTransform(134.25,337.65,0.3809,0.3809,0,0,0,113.3,-92.3);
	new cjs.ButtonHelper(this.you, 0, 1, 1);

	this.kid = new lib.kindergarden();
	this.kid.name = "kid";
	this.kid.setTransform(559.15,206.8,0.3809,0.3809,0,0,0,113.3,-92.2);
	new cjs.ButtonHelper(this.kid, 0, 1, 1);

	this.again = new lib.again();
	this.again.name = "again";
	this.again.setTransform(452.95,206.8,0.3809,0.3809,0,0,0,113.3,-92.2);
	new cjs.ButtonHelper(this.again, 0, 1, 1);

	this.life = new lib.mylife();
	this.life.name = "life";
	this.life.setTransform(346.7,206.8,0.3809,0.3809,0,0,0,113.3,-92.2);
	new cjs.ButtonHelper(this.life, 0, 1, 1);

	this.broke = new lib.brokeup();
	this.broke.name = "broke";
	this.broke.setTransform(240.45,206.8,0.3809,0.3809,0,0,0,113.3,-92.2);
	new cjs.ButtonHelper(this.broke, 0, 1, 1);

	this.haruv = new lib.haruv();
	this.haruv.name = "haruv";
	this.haruv.setTransform(134.25,206.8,0.3809,0.3809,0,0,0,113.3,-92.2);
	new cjs.ButtonHelper(this.haruv, 0, 1, 1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.haruv},{t:this.broke},{t:this.life},{t:this.again},{t:this.kid},{t:this.you},{t:this.where},{t:this.prince},{t:this.know},{t:this.freha}]}).wait(1));

	// odot
	this.odot_b = new lib.odot_1();
	this.odot_b.name = "odot_b";
	this.odot_b.setTransform(43.45,27.35,1,1,0,0,0,28.2,-11);

	this.timeline.addTween(cjs.Tween.get(this.odot_b).wait(1));

	// year
	this.nine = new lib._1979();
	this.nine.name = "nine";
	this.nine.setTransform(623.7,113.7,1,1,0,0,0,17.6,-5.2);

	this.eigth = new lib._1978();
	this.eigth.name = "eigth";
	this.eigth.setTransform(562,113.7,1,1,0,0,0,17.1,-5.2);

	this.seven = new lib._1977();
	this.seven.name = "seven";
	this.seven.setTransform(500.3,113.7,1,1,0,0,0,17.2,-5.2);

	this.six = new lib._1976();
	this.six.name = "six";
	this.six.setTransform(438.6,113.7,1,1,0,0,0,17,-5.2);

	this.five = new lib._1975();
	this.five.name = "five";
	this.five.setTransform(376.9,113.7,1,1,0,0,0,17.4,-5.2);

	this.four = new lib._1974();
	this.four.name = "four";
	this.four.setTransform(315.3,113.7,1,1,0,0,0,18.1,-5.2);

	this.three = new lib._1973();
	this.three.name = "three";
	this.three.setTransform(253.5,114.1,1,1,0,0,0,16.6,-5.7);

	this.two = new lib._1972();
	this.two.name = "two";
	this.two.setTransform(191.85,113.8,1,1,0,0,0,18.2,-5.4);

	this.one = new lib._1971();
	this.one.name = "one";
	this.one.setTransform(130.15,113.7,1,1,0,0,0,16.7,-5.2);

	this.zero = new lib._1970();
	this.zero.name = "zero";
	this.zero.setTransform(52.05,118.9);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.zero},{t:this.one},{t:this.two},{t:this.three},{t:this.four},{t:this.five},{t:this.six},{t:this.seven},{t:this.eigth},{t:this.nine}]}).wait(1));

	// shelf
	this.instance = new lib.Image();
	this.instance.setTransform(595,16,0.0573,0.0573);

	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgbCBIBFixIhuAAIAAhQIAZAAIAAA7IBwAAIAAAWIhFCwg");
	this.shape.setTransform(565.3307,60.644,0.3809,0.3809);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AAyBkIAAiAQAAgYgKgNQgLgMgSAAIg8AAIAACxIgcAAIAAjHIBeAAQAdAAAQASQAQATAAAjIAAB/g");
	this.shape_1.setTransform(558.1989,61.758,0.3809,0.3809);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhMBkIAAgWIBwAAIhpixIAdAAIAyBWIAlhWIAcAAIgyBuIA0BZg");
	this.shape_2.setTransform(550.7623,61.758,0.3809,0.3809);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgKBkIAAidIgFgqIAaAAIAFAqIAACdg");
	this.shape_3.setTransform(545.7157,61.758,0.3809,0.3809);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AhQBSIBAgLIgvivIAcAAIAqCoQAWgKAKgSQAKgTACgdQACgWABhGIAcAAQgBBIgFAlQgGAlgVAVQgUAVgtAJIg9AMg");
	this.shape_4.setTransform(537.6411,61.958,0.3809,0.3809);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgaCBIBEixIhvAAIAAhQIAaAAIAAA7IBxAAIAAAWIhGCwg");
	this.shape_5.setTransform(530.8997,60.644,0.3809,0.3809);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AAwBkIAAiFQAAgXgKgLQgLgKgSAAIhTAAIAAgWIBZAAQA9AAgBBDIAACEgAhKBkIAAhhIADgXIAYAAIAAB4g");
	this.shape_6.setTransform(521.1302,61.758,0.3809,0.3809);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AhehkIAbAAIAMBkQAPgHALgKQAIgKAEgPQAFgRABgUIAAgVIAaAAIgBAVQgBAngOAYQgPAWglAQIAIA3QA4gDAcgfQAdgfgBg8IAAg0IAcAAIAAAzQAABLgpAlQgpAmhSAAg");
	this.shape_7.setTransform(513.0747,61.8247,0.3809,0.3809);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgsBmIAAgWIA9AAIAAh3QABgRgIgJQgGgIgOgDIgYgDIAEgWIAeAFQAWAEALAOQAMANAAAZIAACOg");
	this.shape_8.setTransform(506.1238,61.6819,0.3809,0.3809);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AAwBkIAAiFQAAgXgKgLQgKgKgTAAIhTAAIAAgWIBZAAQA9AAAABDIAACEgAhLBkIAAhhIAEgXIAYAAIAAB4g");
	this.shape_9.setTransform(499.9631,61.758,0.3809,0.3809);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AA6BkIhQh6IgnB6IgbAAIAoh7IAKgYIgig0IAcAAIBCBjIAdhjIAbAAIgpB8IAzBLg");
	this.shape_10.setTransform(489.67,61.758,0.3809,0.3809);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgKBkIAAidIgFgqIAaAAIAFAqIAACdg");
	this.shape_11.setTransform(484.2711,61.758,0.3809,0.3809);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("AhQBSIA/gLIguivIAcAAIArCoQAWgKAKgSQAJgTADgdQABgWABhGIAbAAQAABNgFAgQgFAkgVAWQgVAVgtAJIg8AMg");
	this.shape_12.setTransform(476.1965,61.958,0.3809,0.3809);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgaCBIBEixIhvAAIAAhQIAaAAIAAA7IBxAAIAAAWIhGCwg");
	this.shape_13.setTransform(469.4551,60.644,0.3809,0.3809);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AAwBkIAAiFQAAgXgLgLQgJgKgTAAIhUAAIAAgWIBaAAQA8AAAABDIAACEgAhLBkIAAhhIAFgXIAXAAIAAB4g");
	this.shape_14.setTransform(459.6952,61.758,0.3809,0.3809);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AhcBTQAWgDAHgJQAJgLAAgVIAAiMIBXAAQA8AAAABCIAACEIgcAAIAAiFQAAgXgKgKQgKgLgTAAIg1AAIAAB0QAAAggPAQQgOAPghADg");
	this.shape_15.setTransform(451.5444,61.8533,0.3809,0.3809);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AhOCIIAAitIAEgZIAYAAIAADGgAgTAqQATgDALgGQAOgHAIgRQAJgPACgfIAGhMIiBAAIAAgWICfAAIgHBcQgDAzgYAbQgXAbgnACg");
	this.shape_16.setTransform(443.965,63.1292,0.3809,0.3809);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AgbCBIBFixIhvAAIAAhQIAaAAIAAA7IBxAAIAAAWIhGCwg");
	this.shape_17.setTransform(436.8808,60.644,0.3809,0.3809);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgKgTIgFgqIAaAAIAFAqIAABLIgaAGg");
	this.shape_18.setTransform(432.0722,60.3202,0.3809,0.3809);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AhShjIAbAAIAVCxQApgFAZgWQAZgXgCgvIAAgJQAAgWgLgOQgMgNgXgCIgRgBIACgWIATABQAfACATARQASARABAiIABAKQABA9gmAeQgnAehBADg");
	this.shape_19.setTransform(426.8267,61.758,0.3809,0.3809);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AgdCuIAJhRQATAFAQAAQAmAAAMgYQANgYABgwQgBgxgNgZQgNgXgeAAQgUAAgNAMQgPAMgDAVIgiDfIhtAAIAojkIgxh2IByAAIAUBCQANgmAZgRQAWgSAhAAQBFAAAhAuQAiAwgBBYQAABTgoAwQgpAwhIAAQgcAAgdgHg");
	this.shape_20.setTransform(563.712,29.8122,0.3809,0.3809);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AAsCuIAAjvQAAgbgbAAIilAAIAAhRIDEAAQAxAAAcAcQAcAcAAA6IAADpgAiYCuIAAilIAPgoIBeAAIAADNg");
	this.shape_21.setTransform(549.5911,29.8027,0.3809,0.3809);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AiQCwIgvlgIBnAAIAQCIQAPgJAEgWQAEgSAAguIgBgpIBmAAIAAAnQAABCgZAqQgZAphBAUIAGA3QBQgEAfgoQAegogBhBIgBhyIBtAAIABBsQABB3hKA/QhKA/idAAg");
	this.shape_22.setTransform(530.2147,29.9264,0.3809,0.3809);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AgeCuIAKhRQAUAFAOAAQAmAAANgYQANgYAAgwQAAgxgNgZQgNgXgeAAQgUAAgOAMQgOAMgDAVIgiDfIhtAAIAojkIgxh2IByAAIAUBCQANgmAZgRQAXgSAgAAQBEAAAiAuQAhAwABBYQAABTgpAwQgoAwhJAAQgcAAgegHg");
	this.shape_23.setTransform(514.4649,29.8122,0.3809,0.3809);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AiqBmIBagRIhAkPIBtAAIA1D4QATgKAKgWQAKgVACgcQAEgeAAgxIAAhYIBsAAQgBB2gIA8QgJA7gnAuQgnAshVASIiQAcg");
	this.shape_24.setTransform(499.6679,30.3073,0.3809,0.3809);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AhdCyIAAhRIBPAAIAAidQAAgRgGgHQgGgHgNgBIgsgFIAOhQIBXALQAkAFAUAbQAUAcAAArIAADxg");
	this.shape_25.setTransform(488.7083,29.6503,0.3809,0.3809);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AgyCuIAAkVIgHhGIBsAAIAHBGIAAEVg");
	this.shape_26.setTransform(481.1479,29.8027,0.3809,0.3809);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AiUCuIAAhRICWAAIAAieQAAgbgaAAIh8AAIAAhRICaAAQAwAAAcAcQAdAcAAA6IAACYIAmAAIAABRg");
	this.shape_27.setTransform(467.2079,29.8027,0.3809,0.3809);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AiQCwIgvlgIBnAAIAQCIQAPgJAEgWQAEgSAAguIgBgpIBmAAIAAAnQAABCgZAqQgZAphBAUIAGA3QBQgEAfgoQAegogBhBIgBhyIBtAAIABBsQABB3hKA/QhKA/idAAg");
	this.shape_28.setTransform(452.84,29.9264,0.3809,0.3809);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AhdCyIAAhRIBPAAIAAidQAAgRgGgHQgGgHgOgBIgqgFIAMhQIBYALQAlAFATAbQAUAcAAArIAADxg");
	this.shape_29.setTransform(440.1944,29.6503,0.3809,0.3809);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("AgyCuIAAkVIgHhGIBrAAIAIBGIAAEVg");
	this.shape_30.setTransform(432.634,29.8027,0.3809,0.3809);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AiwBqQAXgDAKgFQAKgFADgLQADgJAAgVIAAjnIDHAAQAxABAcAbQAcAcAAA6IAADpIhtAAIAAjvQAAgbgbAAIg7AAIAACHQAAAzgPAdQgQAeggANQgfAOg3AFg");
	this.shape_31.setTransform(421.7315,30.0217,0.3809,0.3809);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AAsCuIAAjvQAAgbgbAAIilAAIAAhRIDEAAQAxAAAcAcQAcAcAAA6IAADpgAiYCuIAAilIAPgoIBeAAIAADNg");
	this.shape_32.setTransform(403.4304,29.8027,0.3809,0.3809);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AhLAkIAAhHICXAAIAABHg");
	this.shape_33.setTransform(392.7469,30.612,0.3809,0.3809);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("AhJCvQghgYgRgsQgSgtAAg/QAAhfAngyQAmgyBAAAQArAAAfAWQAhAWARAsQASArAABAQAAA/gSAtQgRAsghAYQgfAWgrAAQgqAAgfgWgAgWhtQgKAJgGAaQgFAXAAAyQAABGALAYQAMAZAUAAQAVAAAMgZQALgaAAhEQAAgvgFgaQgGgagKgJQgKgIgNAAQgNAAgJAIg");
	this.shape_34.setTransform(382.6918,29.1742,0.3809,0.3809);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AhGC+QAEg/AJgvQAKgvAUgrQAVgtAhgwIiiAAIAAhWIEPAAIAAA/QgqAxgWAtQgUArgIAwQgIAwgEBTg");
	this.shape_35.setTransform(370.3705,29.1742,0.3809,0.3809);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgyC+QgRgRAAgbQAAgaARgSQARgSAaAAQAZAAARASQARASAAAaQAAAbgRARQgRASgZAAQgaAAgRgSgAg0A3IgBgPQAAgaAMgTQALgTAXgYQANgQAIgKQAHgKAAgKQAAgPgKgIQgJgHgOAAQgNAAgMAGQgLAGgNANIg5g0QAYgbAegOQAfgPAhAAQA1AAAhAaQAhAZAAA3QAAAYgLARQgLASgVAWQgUAUgLAQQgJAQABAXg");
	this.shape_36.setTransform(358.7348,28.7553,0.3809,0.3809);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.lf(["#BDBDBD","#FFFFFF"],[0,1],0,-28.2,0,28.3).s().p("Eh8ZAEbIPko1MDZqAAAIPlI1g");
	this.shape_37.setTransform(346.6896,366.9624,0.3809,0.3809);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.lf(["#DBDBDB","#E5E5E5","#F4F4F4","#FCFCFC","#FFFFFF"],[0,0.094,0.29,0.529,0.902],0,-11.9,0,12).s().p("Eh8ZAB4IAAjuMD4zAAAIAADug");
	this.shape_38.setTransform(346.6896,382.2736,0.3809,0.3809);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.lf(["#BDBDBD","#FFFFFF"],[0,1],0,-28.2,0,28.3).s().p("Eh8ZAEaIPko0MDZqAAAIPlI0g");
	this.shape_39.setTransform(346.6896,236.0939,0.3809,0.3809);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.lf(["#DBDBDB","#E5E5E5","#F4F4F4","#FCFCFC","#FFFFFF"],[0,0.094,0.29,0.529,0.902],0,-11.9,0,12).s().p("Eh8ZAB4IAAjvMD4zAAAIAADvg");
	this.shape_40.setTransform(346.6896,251.405,0.3809,0.3809);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#4784A2").s().p("AgDgDIAHAAIgDAHg");
	this.shape_41.setTransform(246.9733,97.6623,0.3808,0.3808);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#4784A2").s().p("AgNAAIAbgBIgEADg");
	this.shape_42.setTransform(370.0381,96.7198,0.3808,0.3808);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#4784A2").s().p("AgHADQgKgCAHgBQAGgBAKgBIAIAFQgOgBgHABg");
	this.shape_43.setTransform(550.8785,95.9867,0.3808,0.3808);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#4784A2").s().p("AgbAAQAHABAdgBQAYgCgFACIgcACIgFAAQgQAAgGgCg");
	this.shape_44.setTransform(560.3642,95.8357,0.3808,0.3808);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#4784A2").s().p("AgSgBIASAAQAXAAgEADQgSAAgTgDg");
	this.shape_45.setTransform(582.2046,96.2332,0.3808,0.3808);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#4784A2").s().p("AgMAAQAEgCAWABQAAAAAAAAQAAAAgBABQAAAAgBAAQgBAAgBAAIgKADQgQgDAEAAg");
	this.shape_46.setTransform(583.6242,95.8415,0.3808,0.3808);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#4784A2").s().p("AgKAAQAcgCAfgBIhiAHQAEgDAjgBg");
	this.shape_47.setTransform(595.4031,96.4437,0.3808,0.3808);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#4784A2").s().p("AgSAAIATgBQALgBAGABIgMABIgGADg");
	this.shape_48.setTransform(604.1241,96.6008,0.3808,0.3808);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#4784A2").s().p("AgKAAQgOgCAUgEIANAGQAKAEgDADIgagHg");
	this.shape_49.setTransform(645.1119,98.2717,0.3808,0.3808);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#4784A2").s().p("EhaQAA6QnxgHjCABQhdgEkjAFQlEgLi6gEQkRgEjyAFIAqgMQA8gOBcgDQBmgLDUABQDtACBbgFQAIAAAFAFQAEAFAfgCQD6gTH8AaIgPADQAYABAzgEQA2gFAXABIgGACQgEACAGACQAHgEAtgBQAwgBAKgCQAJABAKAEQAKAEANACIAcgIQArgJBfACQByADAtgEIgJACQgEACAGABQBngGCxgCIEogEQgRAGAOADQAKgHBugDQALAEAxgEQA6gFAeACIgFACQAVgEAhACQAdACATgGIAcAHQALgGAhAEQAoAFARgDIgBgCQASgCAZACQAbACAPgBIADABQAWgBBBAAQAfAAgBgFQAMAEghACQghADAXAEQCegFDZgBIF5gBIAiAFQAPACADABIA7gCQAqgBAOgDQgBABAJACIAXACQAWABAagEQAagFAZADQgeADALAEQAagDAugCIBNgCIgMACQgHABABACQAegEAvABQAyACAVgCIgSAEQApAEAIgFQAJgHAgACQgKABgBACIgCACQAlgFBMgBIBxgDIgDABIAAABIBoAAQBBAAAtgCQAGAAAIAHQAHAEAqgBQgBgEA4gDQAvgCgXgGIBsADQBCABAagCQgMACAKAGQAIAEgbAAIAmAHQgCACgSgBQgNAAAGADIA+gCQAvgCAOABQAYgDAxgIQAvgHAvgBQgTACANAGQAJADgCAAIBmgSQALAAAGAEQAGADAUgBQgCgCAbgFIA6ABQA1ABAHAGQAFACgTABQgOABAOACQAZAAAXgCIAxgCIAAABQAbACAbgEQAcgEgYgEQgJAAABADQACACgRgCQAbgHBgAAQgJABgFACQgDADgDABQApgFA5gEIBggFIgHACQgMAEgGAAQArADBagEQBPgEAoAEQAAAAgBAAQAAAAAAgBQAAAAgBAAQAAgBAAAAQAAgGACAEQAVAAAUAEQAPACAOgBQACACAVgBIAqgEQASgDgLADIgGABQAogCBHgCQBqgCA/AEQgBgCAggEQAhgEAQAAIgJAHIAcABIgTACIgRACIAVgBIAWgBQABAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAIAKABIAUAAIAigBQAmgCAZADQgLgBgHAFQgGAFAYAAQAhgBAFgBQAHgCAXgBIAfgDQABgDAZAAQARAAgIgDQAHACAmgBQAoAAgEAGIgIAIQAPAAATgFIAegHQAKACAAABQADgGAiABQArACAPgFQATABBMACQA7ABAPAEIA/gFQAkgCAgABIgPACQgJABgCACQAUACAPgBIAggDQgGACBmAKQAbgCAEgFQACgDAAgFQAUAHA9gFQBBgEAYAFIggAFQgSADAXACQAVAGApgFQAzgHAdADIgPgLQANADArgCQAigCgEAGQAHgCAmABQAbAAgEgGQAmADCHAAQBrAAAkAKIAfgBQASgBgEgDQgOgDgOACQgMADgEgCQAMAAAGgEQAfACAGABQAKACgUAGQAjADAogJQAsgJAuACQgGAGAkgBIAzgHQAlABACAFQABADgFAHIAwgBQAbgCAJgDIAlAJQgOgEAUgBIAlgBIgPACQADACA5gCQgEgEg6gDQAJgCAVgBIAhgDQgEAEAfABIAyAAQARABALgDIANgEQAAACAVAAQAQABgNADIgRgBQgMgBgKACIAVAEQALADAZgDQAKgBAEgHQADgEAfADIgQADIgNAEIA1ADIACgGIAFACIABABQAHgDAogCQAngBAGgEQAPAAAaACQAeADALAAIgFABQAWADAdgCQAagBAVgDIgBABQAuACAggGQATACAKALQAHAHAagEQAfAAARgGQAQgGgOgEQAfACBbgCQBNgBApAFIAJgDQAEgBAOgBICwgCQBogBA1AHQgUACAHADIAMAFQANgCAPACQAKACAFgFQgDgGgCgBQgGgDgWgBQA4gDA9ABQBBAAAbAEQgKgCAFgBIASgDQgEAGAdACQAaACAggDIAGgFIAYAFQAIAAALgFQANgEAXADQAEAEAHACQBkgMAmAEIAjAJQASgBAJgDQAKgDgQgCIBWAGQAnACAOAFQCLgTE8ACIgEAFQAVACAIgEQAHgEAMABQgFACAMAFQAKAEgSADQAhACAdgEQAmgHAJAAQADgDgPACQgOABAEgEIAqABQAnAAAFgFQAQAEgUAJIAigEQAVAEgvAKQgwAJAXAGIAfgBQAPAEgjAEIgMACQABABAbABQAcgDANgHQAOgHgWgCQAjgBATgKQARgJAoABQAJACgeABQgiABAIAEQAUADAigCQAlgEANABQgXgCALgFQAKgEAVgCQATACgKAEQgHADAcAAQAFgCAXgEQAPgEgbgCQALgFAeACQAhACAPgEQAHADgWAJQgQAHAiACQgEgDAigGQAggGgSgGQARACADAEQACADgNAEQANACAqgFQAhgEAGAIIAMgIIArAJQAQAAAsgEQAlgCgCAHIAngCQAdgCgQgFQgTgCgZACQgQACgNgGQATAFAagDIApgGIAEAEIAfgCIAWgCQgGADARACIAQgHQAegBAHAGQAHAGAcgBIgrAFIAVACQATACAQgBQALgGAegMQAPgBAJADQAFACAKgCIgiAGQgGACAXAEQAZAEAeAAQAbgCAOgFQAQgFgegCQATAAAOACQAPADgMADQAZgBgEgEQgGgEAVgBQASAEBYALIgtAKIAeABQgUAEAMADQAQADgKAEQANABATgBIAggDQgggIApgJQAwgJgHgGQAkgBAfANQAXAKAugLQgDgBAFgGQACgDgKAAQANgBAMgDQASgFAgADQgOABACADQABABALAEQATAHgjAEQADgDgVAAIgcABQAFABAHAHQAFAEAfAAIAxgCQAYgCgEgEQgBgDgVAAQgRABALgEQAWgBAqADQAVABAPgHQgbAAgNgEQgKgDABgFIAugDIgJAFQAmACAKgFQALgFAjABIAiAJQgHAEgygBQgqgBAHAIQATAAAjgDQAcgCAZACIghADQAIAAAXAHQAdAGAogGQAVgCgDgCIgIgFQApgBAqgDIA/gEQgFAFAmABQAOAAACABQACABgSADQgUgFg8ABQg+ABgTAHQAOAGgjgBQgugBgIAGQAmAAAOAHQAJAEAGAIQAKABAOgCIATgDQAEgEgJgDQgKgEgBgDQAxACAvgDQAtgCAdgFQARACgFAEQgDAEgQAAQB2gCB3AEQgZgGAtgBQAggBADgCQAKALgCABQAagCgBADQgBAFAaAAQBKgHBmgDQAtAFBUgCIB7gEQAQACAHAHQAGAHATABQAVAAgNgFQgJgEAhACIgGACQAKgBA7ACQAxABAPgHIgPAJIARgBIAQgCQABACAEADQACADgMABQAYAEAmgCIBBgDIgcgHQApgCA6ABQBDABAfgBIgDAHIArgEQgIAEAVACQAOABAMgBIhjANQgPgCASgEQAWgEgKgDQgNgEgkABQglABgIAEQAQAAAJAAIAVgCQAFAEgTADIgjAGIAVABIAFAAQgdADg6ABQAQgCgMgDIgKgCQgIAKhagDQgVgFg0AEQhBAFgagBQAsgNA0gEQgUgCgWAAQgWAAgTgBQgSAGgMADQgWAGggACIgDgFQgRABgfAFQgYAEgigBIkagDIgDgGQgZAHhGABQhXAAgTACQgrgChrACQhXABgcgFQlIAIiygCIAfgIQgSADgJgDQgMgEgOAAQAWAEghAEIg3AGQhbgHijAOIgDgGQgsAHhJgDIiCgFIgVgEQgQgDgQAAQgeAGgiADIhRAGQhjAAhagGQhuAHi7ABQjfABhPADIgPgGQhuAIjMgBQjjgChDADIARgLQgogDgmAEQgnAEAKAGQgTgBhHABQg5ACgTgGQgfgBgcADIg0AFQhKgDg1AAIhdABQABAAABgBQAAAAABgBQAAAAAAgBQAAAAgBAAQgCgDgSgBIhQACQgtABAXAIQgzgEiCADQh7ACg4gFQAFACgMACIgWADIiQgDQhTgCgtAEQgGgBAHgDQAGgDgWAAQgLAAgCADQgBADgPABQhXAEiRgFQipgFg1AAQiaAFjiAAIlzAAIACgDQglAFhfgEQhWgEgiAJIgqgDQgZgBAIgDQgdADhggDQhOgCgvACQgvgChWABQhbABgwgCIASgCQALgBACgCQgPgCgvAEQgmAEgLgIQgPAAABAEQABACAHABQiEgEjDAEIlTAGQhWgEAFgJQACgEg6AEQgGgBgBADIgCABQgYABglgHQgggGgRAEQAIAEgPACQgRABAAACIhqgHQgrgDgvAEIAGgEQgrAFhjAEQhbADgoAHQjnABn+AGQnYAEkEABIrRAAQm7ABkcgFQhWgIgjgBQgigBhfAEIAHgCQABAAAAAAQAAgBAAAAQAAAAgBAAQgBgBgCAAQgDAFgtAAQgvAAgGAFQhpgBihABIkOABQAXgBAGgEQAGgEgZABIglAGIgGgDQgVABgKADQgMADARACQhpABiIAAQjFAAkFgDgAnfgcQAJABABACQANgDgRAAIgGAAgEBqJgAiQghgCgSgFQgTgFAQgDQAPAAgEADQgFADAEABQAPgCAbAEIANABQgLACACAEIgCgBg");
	this.shape_50.setTransform(343.3944,97.9345,0.3808,0.3808);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#4784A2").s().p("AgSACQAegBgPgCIgEgBIAaACQgKADgNAAIgOgBg");
	this.shape_51.setTransform(649.1285,98.4135,0.3808,0.3808);

	this.instance_1 = new lib.Image_1();
	this.instance_1.setTransform(-19,-8,0.0941,0.0941);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape},{t:this.instance}]}).wait(1));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(293,164,480.5,270.8);
// library properties:
lib.properties = {
	id: '32B64D0D77404BE98ED70BF593083F14',
	width: 712,
	height: 400,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/Image.png", id:"Image"},
		{src:"images/Image_1.png", id:"Image_1"},
		{src:"images/FlashAICBAssets.png", id:"FlashAICBAssets"},
		{src:"images/FlashAICBAssets_1.png", id:"FlashAICBAssets_1"},
		{src:"images/FlashAICBAssets_2.png", id:"FlashAICBAssets_2"},
		{src:"images/FlashAICBAssets_3.png", id:"FlashAICBAssets_3"},
		{src:"images/FlashAICBAssets_4.png", id:"FlashAICBAssets_4"},
		{src:"images/FlashAICBAssets_5.png", id:"FlashAICBAssets_5"},
		{src:"images/FlashAICBAssets_6.png", id:"FlashAICBAssets_6"},
		{src:"images/FlashAICBAssets_7.png", id:"FlashAICBAssets_7"},
		{src:"images/FlashAICBAssets_8.png", id:"FlashAICBAssets_8"},
		{src:"images/FlashAICBAssets_9.png", id:"FlashAICBAssets_9"},
		{src:"images/linkfaqulty.png", id:"linkfaqulty"},
		{src:"images/odot.png", id:"odot"},
		{src:"images/songagain.png", id:"songagain"},
		{src:"images/songbroke.png", id:"songbroke"},
		{src:"images/songfreha.png", id:"songfreha"},
		{src:"images/songharuv.png", id:"songharuv"},
		{src:"images/songkid.png", id:"songkid"},
		{src:"images/songknow.png", id:"songknow"},
		{src:"images/songlife.png", id:"songlife"},
		{src:"images/songprince.png", id:"songprince"},
		{src:"images/songwhere.png", id:"songwhere"},
		{src:"images/songyou.png", id:"songyou"},
		{src:"images/x.png", id:"x"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['32B64D0D77404BE98ED70BF593083F14'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused || stageChild.ignorePause){
			stageChild.syncStreamSounds();
		}
	}
}
an.handleFilterCache = function(event) {
	if(!event.paused){
		var target = event.target;
		if(target){
			if(target.filterCacheList){
				for(var index = 0; index < target.filterCacheList.length ; index++){
					var cacheInst = target.filterCacheList[index];
					if((cacheInst.startFrame <= target.currentFrame) && (target.currentFrame <= cacheInst.endFrame)){
						cacheInst.instance.cache(cacheInst.x, cacheInst.y, cacheInst.w, cacheInst.h);
					}
				}
			}
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;